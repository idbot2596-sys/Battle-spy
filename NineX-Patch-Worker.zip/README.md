# NineX Patch Delivery Worker

Files:
- `src/index.js` — Worker
- `public/patch.bytes` — exact binary payload

patch.bytes:
- Size: 5497 bytes
- SHA-256: 08eae82bc9d859e294adb41cf7def38543f8594a096f41b4e329bc28cea7ea16

Deploy with:
```bash
npx wrangler login
npx wrangler deploy
```

After deployment:
`https://<worker-name>.<subdomain>.workers.dev/patch.bytes`

The Worker serves the uploaded bytes as `application/octet-stream`.
